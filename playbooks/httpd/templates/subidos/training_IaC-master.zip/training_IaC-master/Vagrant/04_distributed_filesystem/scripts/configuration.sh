echo "192.168.33.200	master" >> /etc/hosts
echo "192.168.33.11	node1" >> /etc/hosts
echo "192.168.33.12	node2" >> /etc/hosts
