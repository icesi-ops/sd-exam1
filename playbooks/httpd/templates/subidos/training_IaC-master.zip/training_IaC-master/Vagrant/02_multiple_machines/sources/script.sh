#!/bin/bash

echo $HOSTNAME
echo `ip a`
